package com.capi.exception;

public class DuplicateId extends Exception {

	@Override
	public String toString() {
		return "DuplicateId []";
	}

}
