package com.capi.exception;

public class InsufficientBalanceExceptions extends Exception {

	@Override
	public String toString() {
		return "InsufficientBalanceExceptions []";
	}

}
