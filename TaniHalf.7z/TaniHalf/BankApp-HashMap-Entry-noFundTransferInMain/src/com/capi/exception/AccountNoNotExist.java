package com.capi.exception;

public class AccountNoNotExist extends Exception {

	@Override
	public String toString() {
		return "AccountNoNotExist []";
	}

}
