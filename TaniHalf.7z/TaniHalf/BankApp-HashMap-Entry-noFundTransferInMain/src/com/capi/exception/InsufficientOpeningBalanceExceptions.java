package com.capi.exception;

public class InsufficientOpeningBalanceExceptions extends Exception {

	@Override
	public String toString() {
		return "InsufficientOpeningBalanceExceptions []";
	}

}
