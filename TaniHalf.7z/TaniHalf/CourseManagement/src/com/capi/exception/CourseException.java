package com.capi.exception;

public class CourseException extends Exception {

	public CourseException(String string) {
		// TODO Auto-generated constructor stub
	}

	
	@Override
	public String toString() {
		return "CourseException []";
	}

}
