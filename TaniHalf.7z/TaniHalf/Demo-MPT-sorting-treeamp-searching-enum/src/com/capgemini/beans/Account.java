package com.capgemini.beans;

public class Account {
	private int id;
	private double balance;
	private String name;

	public Account() {
		// TODO Auto-generated constructor stub
	}
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public String toString() {
		return "["+ name +"/"+ balance + "/"+ id +"]";
	}






}
