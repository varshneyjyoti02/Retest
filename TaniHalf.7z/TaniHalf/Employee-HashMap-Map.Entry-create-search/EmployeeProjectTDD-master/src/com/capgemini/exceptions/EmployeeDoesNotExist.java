package com.capgemini.exceptions;

public class EmployeeDoesNotExist extends Exception {

}
