package com.capgemini.exceptions;

public class InvalidAddressException extends Exception {

}
