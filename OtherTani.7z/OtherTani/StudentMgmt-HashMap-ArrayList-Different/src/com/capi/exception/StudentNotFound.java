package com.capi.exception;

public class StudentNotFound extends Exception {

	@Override
	public String toString() {
		return "StudentNotFound []";
	}

}
