package com.capi.tani.exception;

import java.util.Arrays;

public class ProductNotFound extends Exception{

	@Override
	public String toString() {
		return "ProductNotFound";
	}

}
