package com.capgemini.exceptions;

public class InsufficientBalanceException extends Exception {

}
