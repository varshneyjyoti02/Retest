package com.cg.mra.exceptions;

import java.util.Arrays;

public class InvalidPhoneNoException extends Exception{

	@Override
	public String toString() {
		return "Invalid No";
	}
	
}
