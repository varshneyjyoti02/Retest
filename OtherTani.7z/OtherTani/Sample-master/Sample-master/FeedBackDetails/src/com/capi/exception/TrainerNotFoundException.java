package com.capi.exception;

public class TrainerNotFoundException extends Exception {

	@Override
	public String toString() {
		return "TrainerNotFoundException []";
	}

}
