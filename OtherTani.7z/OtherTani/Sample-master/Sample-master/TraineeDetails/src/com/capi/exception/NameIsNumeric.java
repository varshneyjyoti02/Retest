package com.capi.exception;

public class NameIsNumeric extends Exception {

	@Override
	public String toString() {
		return "NameIsNumeric []";
	}

}
