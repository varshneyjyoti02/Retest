package com.capi.exception;

public class NoSuchTypeRating extends Exception {

	@Override
	public String toString() {
		return "NoSuchTypeRating []";
	}

}
