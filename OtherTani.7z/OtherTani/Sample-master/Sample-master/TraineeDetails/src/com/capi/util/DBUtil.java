package com.capi.util;

import java.time.LocalDate;
import java.util.HashMap;

import com.capi.beans.Trainer;

public class DBUtil {
	

	public static double generateId()
	{
				
		
		return Math.random()*1000;

		
	}
}
